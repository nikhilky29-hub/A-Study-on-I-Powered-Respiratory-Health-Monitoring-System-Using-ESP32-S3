"""
TinyML Backend Server for Wokwi Simulators
Provides TensorFlow Lite inference for Arduino/Wokwi projects
"""
import json
import pathlib
from flask import Flask, request, jsonify
from flask_cors import CORS
import numpy as np
import tensorflow as tf

app = Flask(__name__)
CORS(app)  # Allow cross-origin requests from Wokwi

# Load models for each project
models = {}

def load_model(project_name: str, model_path: pathlib.Path):
    """Load a TensorFlow Lite model."""
    if not model_path.exists():
        print(f"Warning: Model not found at {model_path}")
        return None
    
    try:
        interpreter = tf.lite.Interpreter(model_path=str(model_path))
        interpreter.allocate_tensors()
        models[project_name] = interpreter
        print(f"✓ Loaded model for {project_name}")
        return interpreter
    except Exception as e:
        print(f"Error loading model for {project_name}: {e}")
        return None

# Initialize models
base_dir = pathlib.Path(__file__).parent.parent.parent
model_paths = {
    'remote_worker_monitor': base_dir / 'remote_worker_monitor' / 'ml' / 'training' / 'artifacts' / 'guardian_model.tflite',
    'health_monitor': base_dir / 'health_monitor' / 'ml' / 'training' / 'artifacts' / 'guardian_model.tflite',
    'office_energy_system': base_dir / 'office_energy_system' / 'ml' / 'training' / 'artifacts' / 'guardian_model.tflite',
    'greenhouse_farming_system': base_dir / 'greenhouse_farming_system' / 'ml' / 'training' / 'artifacts' / 'guardian_model.tflite',
    'respiratory_health_monitor': base_dir / 'respiratory_health_monitor' / 'ml' / 'training' / 'artifacts' / 'guardian_model.tflite',
    'smart_energy_system': base_dir / 'smart_energy_system' / 'ml' / 'training' / 'artifacts' / 'guardian_model.tflite',
    'smart_irrigation_system': base_dir / 'smart_irrigation_system' / 'ml' / 'training' / 'artifacts' / 'guardian_model.tflite',
}

for project, path in model_paths.items():
    load_model(project, path)

@app.route('/health', methods=['GET'])
def health():
    """Health check endpoint."""
    return jsonify({
        'status': 'ok',
        'models_loaded': list(models.keys())
    })

@app.route('/infer', methods=['POST'])
def infer():
    """Run inference on input features."""
    try:
        data = request.json
        project = data.get('project', 'respiratory_health_monitor')
        features = np.array(data['features'], dtype=np.float32)
        
        if project not in models:
            return jsonify({
                'error': f'Model not loaded for project: {project}',
                'available': list(models.keys())
            }), 400
        
        interpreter = models[project]
        
        # Get input and output tensors
        input_details = interpreter.get_input_details()
        output_details = interpreter.get_output_details()
        
        # Ensure features match expected shape
        expected_shape = input_details[0]['shape']
        if features.shape != tuple(expected_shape):
            features = features.reshape(expected_shape)
        
        # Handle quantized models (INT8)
        input_dtype = input_details[0]['dtype']
        if input_dtype == np.int8:
            # Quantize float32 features to INT8
            input_scale = input_details[0]['quantization_parameters']['scales'][0]
            input_zero_point = input_details[0]['quantization_parameters']['zero_points'][0]
            quantized_features = (features / input_scale + input_zero_point).astype(np.int8)
            interpreter.set_tensor(input_details[0]['index'], quantized_features)
        else:
            # Float32 model
            interpreter.set_tensor(input_details[0]['index'], features.astype(np.float32))
        
        # Run inference
        interpreter.invoke()
        
        # Get output
        output = interpreter.get_tensor(output_details[0]['index'])
        
        # Handle quantized outputs (INT8)
        output_dtype = output_details[0]['dtype']
        if output_dtype == np.int8:
            # Dequantize INT8 output to float32
            output_scale = output_details[0]['quantization_parameters']['scales'][0]
            output_zero_point = output_details[0]['quantization_parameters']['zero_points'][0]
            probabilities = ((output[0].astype(np.float32) - output_zero_point) * output_scale).tolist()
        else:
            probabilities = output[0].tolist()
        
        # Find winning class
        max_idx = int(np.argmax(probabilities))
        
        return jsonify({
            'probabilities': probabilities,
            'winning_index': max_idx,
            'success': True
        })
    
    except Exception as e:
        return jsonify({
            'error': str(e),
            'success': False
        }), 500

@app.route('/heuristic', methods=['POST'])
def heuristic():
    """Fallback heuristic inference if model not available."""
    data = request.json
    project = data.get('project', 'respiratory_health_monitor')
    features = data.get('features', [])
    
    # Simple heuristic (same as dashboard fallback)
    if len(features) >= 6:
        hr, hrv, voice, blink, fatigue, motion = features[:6]
        
        logits = [
            1.2 - fatigue * 0.8 - voice * 0.6 - motion * 0.5,
            fatigue * 1.4 + (1 - blink) * 0.6,
            voice * 1.5 + (1 - hrv) * 0.8,
            motion * 1.2 + hr * 0.8 + (1 - hrv) * 0.6,
        ]
        
        exp = [np.exp(l) for l in logits]
        sum_exp = sum(exp)
        probabilities = [e / sum_exp for e in exp]
        max_idx = probabilities.index(max(probabilities))
        
        return jsonify({
            'probabilities': probabilities,
            'winning_index': max_idx,
            'success': True,
            'method': 'heuristic'
        })
    
    return jsonify({'error': 'Invalid features', 'success': False}), 400

if __name__ == '__main__':
    print("=" * 60)
    print("TinyML Backend Server for Wokwi")
    print("=" * 60)
    print(f"Models loaded: {len(models)}")
    print(f"Available projects: {list(models.keys())}")
    print("\nServer starting on http://localhost:5000")
    print("Endpoints:")
    print("  GET  /health - Health check")
    print("  POST /infer - Run ML inference")
    print("  POST /heuristic - Fallback heuristic inference")
    print("=" * 60)
    
    app.run(host='0.0.0.0', port=5000, debug=False)

