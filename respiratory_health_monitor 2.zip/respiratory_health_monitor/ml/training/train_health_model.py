"""
Train TinyML model for Respiratory Health Monitor
Classifies respiratory distress states: Normal, Mild Distress, Moderate Distress, Severe Distress
"""

from __future__ import annotations

import argparse
import pathlib
from dataclasses import dataclass
from typing import Tuple

import numpy as np
import tensorflow as tf

NUM_FEATURES = 16
NUM_CLASSES = 4


@dataclass
class Dataset:
    x: np.ndarray
    y: np.ndarray


def generate_dataset(
    samples: int = 4000,
    seed: int | None = None,
) -> Tuple[Dataset, Dataset]:
    rng = np.random.default_rng(seed)
    
    # Base signals for respiratory health
    respiratory_rate = rng.normal(16, 4, samples)  # breaths per minute
    voice_quality = rng.beta(3, 2, samples)  # 0-1, higher = worse
    cough_frequency = rng.exponential(2, samples)  # coughs per minute
    breathing_pattern = rng.beta(2, 5, samples)  # irregularity indicator
    voice_amplitude = rng.beta(2, 3, samples)
    spectral_centroid = rng.beta(3, 3, samples)
    
    # State logic
    labels = np.zeros(samples, dtype=np.int32)
    # Mild distress: moderate voice issues or slight breathing changes
    labels[(voice_quality > 0.4) | (breathing_pattern > 0.3)] = 1
    # Moderate distress: clear voice issues or breathing irregularities
    labels[(voice_quality > 0.6) | (breathing_pattern > 0.5) | (cough_frequency > 5)] = 2
    # Severe distress: extreme rates or multiple indicators
    labels[(respiratory_rate > 24) | (respiratory_rate < 10) | 
           (voice_quality > 0.8) | (breathing_pattern > 0.8) | (cough_frequency > 10)] = 3
    
    # Normalize features
    resp_norm = np.clip((respiratory_rate - 8) / 22, 0, 1)
    voice_norm = np.clip(voice_quality, 0, 1)
    cough_norm = np.clip(cough_frequency / 20, 0, 1)
    pattern_norm = np.clip(breathing_pattern, 0, 1)
    amplitude_norm = np.clip(voice_amplitude, 0, 1)
    
    features = np.stack(
        [
            resp_norm,
            voice_norm,
            cough_norm,
            pattern_norm,
            amplitude_norm,
            spectral_centroid,
            np.ones(samples),  # validity flags
            np.ones(samples),
            np.ones(samples),
        ],
        axis=1,
    )
    
    # Pad to 16 dims
    pad = np.tile(amplitude_norm, (7, 1)).T
    features = np.concatenate([features, pad], axis=1)[:, :NUM_FEATURES]
    
    permutation = rng.permutation(samples)
    train_idx = permutation[: int(samples * 0.8)]
    val_idx = permutation[int(samples * 0.8) :]
    
    x_train = features[train_idx].astype(np.float32)
    y_train = labels[train_idx]
    x_val = features[val_idx].astype(np.float32)
    y_val = labels[val_idx]
    
    return Dataset(x_train, y_train), Dataset(x_val, y_val)


def build_model() -> tf.keras.Model:
    inputs = tf.keras.Input(shape=(NUM_FEATURES,), name="features")
    x = tf.keras.layers.Dense(32, activation="relu")(inputs)
    x = tf.keras.layers.Dense(32, activation="relu")(x)
    x = tf.keras.layers.Dense(16, activation="relu")(x)
    outputs = tf.keras.layers.Dense(NUM_CLASSES, activation="softmax")(x)
    model = tf.keras.Model(inputs, outputs)
    model.compile(
        optimizer=tf.keras.optimizers.Adam(1e-3),
        loss="sparse_categorical_crossentropy",
        metrics=["accuracy"],
    )
    return model


def train(output_dir: pathlib.Path, epochs: int, batch_size: int) -> None:
    output_dir.mkdir(parents=True, exist_ok=True)
    train_ds, val_ds = generate_dataset()
    model = build_model()
    model.summary()
    history = model.fit(
        train_ds.x,
        train_ds.y,
        validation_data=(val_ds.x, val_ds.y),
        epochs=epochs,
        batch_size=batch_size,
        verbose=2,
    )
    
    val_acc = history.history['val_accuracy'][-1]
    print(f"\n✓ Validation accuracy: {val_acc:.1%}")

    keras_path = output_dir / "guardian_model.keras"
    model.save(keras_path)

    converter = tf.lite.TFLiteConverter.from_keras_model(model)
    converter.optimizations = [tf.lite.Optimize.DEFAULT]
    tflite_model = converter.convert()
    tflite_path = output_dir / "guardian_model.tflite"
    tflite_path.write_bytes(tflite_model)
    
    # Save for TensorFlow.js (browser use)
    try:
        import tensorflowjs as tfjs
        tfjs_dir = output_dir / "tfjs_model"
        tfjs_dir.mkdir(exist_ok=True)
        tfjs.converters.save_keras_model(model, str(tfjs_dir))
        print(f"✓ TensorFlow.js model saved to {tfjs_dir}")
    except ImportError:
        print("⚠ tensorflowjs not installed. Install with: pip install tensorflowjs")
        print("  TensorFlow.js model not generated. Dashboard will use heuristic fallback.")


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Respiratory Health Monitor TinyML trainer")
    parser.add_argument(
        "--output",
        type=pathlib.Path,
        default=pathlib.Path("artifacts"),
        help="Directory to store exported models",
    )
    parser.add_argument("--epochs", type=int, default=30)
    parser.add_argument("--batch-size", type=int, default=64)
    return parser.parse_args()


def main() -> None:
    args = parse_args()
    train(args.output, args.epochs, args.batch_size)


if __name__ == "__main__":
    main()

