#pragma once

#include <cstdint>

/**
 * @brief Spirometry Flow Sensor Driver
 * 
 * Vortex flow sensor for FEV1, FVC, and PEF measurements
 * Differential pressure sensor with temperature compensation
 */
class SpirometrySensor {
public:
    SpirometrySensor(int i2c_port, int sda_pin, int scl_pin);
    
    bool init();
    
    /**
     * @brief Read spirometry metrics
     * @param fev1 Output: Forced expiratory volume 1s (mL)
     * @param fvc Output: Forced vital capacity (mL)
     * @param pef Output: Peak expiratory flow (L/s)
     * @param valid Output: Measurement validity
     */
    void read_spirometry(float& fev1, float& fvc, float& pef, bool& valid);

private:
    int i2c_port_;
    int sda_pin_;
    int scl_pin_;
};

/**
 * @brief Air Quality Sensor Driver (PM2.5, PM10, Pollutants)
 */
class AirQualitySensor {
public:
    AirQualitySensor(int uart_port);
    
    bool init();
    
    /**
     * @brief Read air quality metrics
     * @param pm25 Output: PM2.5 (µg/m³)
     * @param pm10 Output: PM10 (µg/m³)
     * @param nox Output: NOx level (ppb)
     * @param o3 Output: Ozone level (ppb)
     * @param valid Output: Measurement validity
     */
    void read_air_quality(float& pm25, float& pm10, float& nox, float& o3, bool& valid);

private:
    int uart_port_;
};
