#include "simulation.hpp"

#include <cmath>

#include "esp_timer.h"

namespace {
float randf() {
    return static_cast<float>(esp_random() % 10000) / 10000.0f;
}
}  // namespace

esp_err_t SensorSimulator::init() {
    time_s_ = 0.0f;
    return ESP_OK;
}

esp_err_t SensorSimulator::sample(SensorReadings &out_readings) {
    time_s_ += 0.2f;
    const float circadian = std::sin(time_s_ * 0.05f) * 5.0f;

    // Heart metrics
    out_readings.heart_rate_bpm =
        72.0f + circadian + std::sin(time_s_ * 0.8f) * 3.0f + randf() * 2.0f;
    out_readings.heart_rate_variability =
        45.0f + std::sin(time_s_ * 0.7f) * 8.0f - stress_state_ * 10.0f;

    // Voice stress: occasionally spike to simulate tense meetings
    if (randf() > 0.92f) {
        stress_state_ = std::min(1.0f, stress_state_ + 0.3f);
    } else {
        stress_state_ *= 0.98f;
    }
    out_readings.voice_stress_score =
        clamp01(0.15f + stress_state_ + randf() * 0.05f);

    // Facial fatigue
    if (randf() > 0.95f) {
        fatigue_state_ = std::min(1.0f, fatigue_state_ + 0.2f);
    } else {
        fatigue_state_ *= 0.995f;
    }
    out_readings.blink_rate =
        18.0f - fatigue_state_ * 8.0f + randf() * 2.0f;
    out_readings.facial_fatigue_score =
        clamp01(fatigue_state_ + randf() * 0.02f);

    // IMU motion -> correlate with stress spikes
    out_readings.imu_motion_score =
        clamp01(stress_state_ * 0.5f + randf() * 0.2f);

    out_readings.ppg_valid = true;
    out_readings.voice_valid = true;
    out_readings.face_valid = true;
    return ESP_OK;
}

float SensorSimulator::clamp01(float value) const {
    if (value < 0.0f) return 0.0f;
    if (value > 1.0f) return 1.0f;
    return value;
}



