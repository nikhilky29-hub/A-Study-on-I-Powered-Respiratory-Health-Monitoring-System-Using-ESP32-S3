#pragma once

#include <string>

#include "ai_processor.hpp"
#include "sensors.hpp"
#include "esp_mqtt_client.h"

class CloudClient {
public:
    esp_err_t init();
    esp_err_t publish(const SensorReadings &readings,
                      const InferenceResult &result);
    void loop();

private:
    esp_mqtt_client_handle_t client_ = nullptr;
    int last_packet_ms_ = 0;
};

