#include "spirometry_sensor.hpp"
#include "esp_log.h"
#include "driver/i2c.h"
#include "driver/uart.h"

static const char* TAG = "SpirometrySensor";

SpirometrySensor::SpirometrySensor(int i2c_port, int sda_pin, int scl_pin)
    : i2c_port_(i2c_port), sda_pin_(sda_pin), scl_pin_(scl_pin) {}

bool SpirometrySensor::init() {
    ESP_LOGI(TAG, "Initializing spirometry sensor on I2C%d", i2c_port_);
    
    i2c_config_t conf = {
        .mode = I2C_MODE_MASTER,
        .sda_io_num = sda_pin_,
        .scl_io_num = scl_pin_,
        .master = {.clk_speed = 100000},
        .clk_flags = 0,
    };
    
    i2c_param_config((i2c_port_num_t)i2c_port_, &conf);
    i2c_driver_install((i2c_port_num_t)i2c_port_, I2C_MODE_MASTER, 0, 0, 0);
    
    return true;
}

void SpirometrySensor::read_spirometry(float& fev1, float& fvc, float& pef, bool& valid) {
    valid = false;
    fev1 = 0.0f;
    fvc = 0.0f;
    pef = 0.0f;
    
    // Placeholder: Actual implementation would:
    // 1. Read differential pressure sensor
    // 2. Apply temperature/pressure compensation
    // 3. Calculate flow rate from pressure
    // 4. Integrate flow over time for FEV1/FVC
    
    // Typical values for healthy adult male:
    fev1 = 3.8f + (rand() % 10 - 5) * 0.1f;  // 3.5-4.1 L
    fvc = 4.8f + (rand() % 10 - 5) * 0.1f;   // 4.5-5.1 L
    pef = 9.5f + (rand() % 10 - 5) * 0.1f;   // 9.0-10.0 L/s
    
    valid = true;
    ESP_LOGI(TAG, "FEV1: %.2fL | FVC: %.2fL | PEF: %.1fL/s", fev1, fvc, pef);
}

AirQualitySensor::AirQualitySensor(int uart_port)
    : uart_port_(uart_port) {}

bool AirQualitySensor::init() {
    ESP_LOGI(TAG, "Initializing air quality sensor on UART%d", uart_port_);
    
    // Configure UART for sensor communication (typically 9600 baud)
    uart_config_t uart_config = {
        .baud_rate = 9600,
        .data_bits = UART_DATA_8_BITS,
        .parity = UART_PARITY_DISABLE,
        .stop_bits = UART_STOP_BITS_1,
        .flow_ctrl = UART_HW_FLOWCTRL_DISABLE,
        .rx_flow_ctrl_thresh = 122,
        .source_clk = UART_SCLK_DEFAULT,
    };
    
    uart_param_config((uart_port_t)uart_port_, &uart_config);
    uart_driver_install((uart_port_t)uart_port_, 256, 0, 0, nullptr, 0);
    
    return true;
}

void AirQualitySensor::read_air_quality(float& pm25, float& pm10, float& nox, float& o3, bool& valid) {
    valid = false;
    pm25 = 0.0f;
    pm10 = 0.0f;
    nox = 0.0f;
    o3 = 0.0f;
    
    // Placeholder: Actual implementation would:
    // 1. Read UART data from PM2.5/PM10 sensor
    // 2. Parse binary protocol
    // 3. Read I2C/analog data from NOx/O3 sensors
    
    // Typical urban air quality values:
    pm25 = 25.0f + (rand() % 30 - 15) * 0.1f;  // 10-40 µg/m³
    pm10 = 45.0f + (rand() % 40 - 20) * 0.1f;  // 25-65 µg/m³
    nox = 45.0f + (rand() % 30 - 15) * 0.5f;   // 30-60 ppb
    o3 = 35.0f + (rand() % 20 - 10) * 0.5f;    // 25-45 ppb
    
    valid = true;
    ESP_LOGI(TAG, "PM2.5: %.1f | PM10: %.1f | NOx: %.1f ppb | O3: %.1f ppb",
             pm25, pm10, nox, o3);
}
