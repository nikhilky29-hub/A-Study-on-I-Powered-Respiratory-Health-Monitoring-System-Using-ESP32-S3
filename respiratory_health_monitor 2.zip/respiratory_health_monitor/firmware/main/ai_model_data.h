#pragma once

#include <cstdint>

extern const unsigned char g_health_model_data[];
extern const int g_health_model_data_len;


