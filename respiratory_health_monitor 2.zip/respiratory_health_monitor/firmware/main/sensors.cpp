#include "sensors.hpp"

#include <cmath>
#include <cstring>

#include "driver/gpio.h"
#include "driver/i2c.h"
#include "driver/i2s.h"
#include "driver/ledc.h"
#include "esp_camera.h"
#include "esp_log.h"

#ifdef CONFIG_WORKER_MONITOR_SENSOR_SIMULATION
#include "simulation.hpp"
#endif

namespace {
constexpr char kTag[] = "WorkerSensorHub";

constexpr gpio_num_t kPpgScl = GPIO_NUM_9;
constexpr gpio_num_t kPpgSda = GPIO_NUM_8;
constexpr i2c_port_t kI2cPort = I2C_NUM_0;

constexpr gpio_num_t kMicBck = GPIO_NUM_5;
constexpr gpio_num_t kMicWs = GPIO_NUM_6;
constexpr gpio_num_t kMicData = GPIO_NUM_7;

constexpr gpio_num_t kLedPin = GPIO_NUM_48;
#ifdef CONFIG_WORKER_MONITOR_SENSOR_SIMULATION
static SensorSimulator simulator;
#endif
}  // namespace

}  // namespace

esp_err_t SensorHub::init() {
#ifdef CONFIG_WORKER_MONITOR_SENSOR_SIMULATION
    return simulator.init();
#else
    ESP_RETURN_ON_ERROR(init_ppg(), kTag, "PPG init failed");
    ESP_RETURN_ON_ERROR(init_microphone(), kTag, "Mic init failed");
    ESP_RETURN_ON_ERROR(init_camera(), kTag, "Camera init failed");
    ESP_RETURN_ON_ERROR(init_imu(), kTag, "IMU init failed");
    return ESP_OK;
#endif
}

esp_err_t SensorHub::sample(SensorReadings &out_readings) {
    memset(&out_readings, 0, sizeof(out_readings));
#ifdef CONFIG_WORKER_MONITOR_SENSOR_SIMULATION
    return simulator.sample(out_readings);
#else
    ESP_RETURN_ON_ERROR(read_ppg(out_readings.heart_rate_bpm,
                                 out_readings.heart_rate_variability,
                                 out_readings.ppg_valid),
                        kTag, "PPG read failed");
    ESP_RETURN_ON_ERROR(read_voice(out_readings.voice_stress_score,
                                   out_readings.voice_valid),
                        kTag, "Voice read failed");
    ESP_RETURN_ON_ERROR(read_face(out_readings.blink_rate,
                                  out_readings.facial_fatigue_score,
                                  out_readings.face_valid),
                        kTag, "Face read failed");
    ESP_RETURN_ON_ERROR(read_imu(out_readings.imu_motion_score),
                        kTag, "IMU read failed");
    return ESP_OK;
#endif
}

esp_err_t SensorHub::init_ppg() {
    i2c_config_t cfg{};
    cfg.mode = I2C_MODE_MASTER;
    cfg.scl_io_num = kPpgScl;
    cfg.sda_io_num = kPpgSda;
    cfg.scl_pullup_en = GPIO_PULLUP_ENABLE;
    cfg.sda_pullup_en = GPIO_PULLUP_ENABLE;
    cfg.master.clk_speed = 400000;
    ESP_RETURN_ON_ERROR(i2c_param_config(kI2cPort, &cfg), kTag, "i2c config");
    ESP_RETURN_ON_ERROR(i2c_driver_install(kI2cPort, cfg.mode, 0, 0, 0),
                        kTag, "i2c install");
    return ESP_OK;
}

esp_err_t SensorHub::init_microphone() {
    i2s_config_t i2s_config{};
    i2s_config.mode = static_cast<i2s_mode_t>(I2S_MODE_MASTER | I2S_MODE_RX);
    i2s_config.sample_rate = 16000;
    i2s_config.bits_per_sample = I2S_BITS_PER_SAMPLE_32BIT;
    i2s_config.channel_format = I2S_CHANNEL_FMT_ONLY_LEFT;
    i2s_config.communication_format = I2S_COMM_FORMAT_STAND_I2S;
    i2s_config.dma_buf_count = 4;
    i2s_config.dma_buf_len = 256;
    i2s_config.use_apll = false;
    i2s_config.intr_alloc_flags = ESP_INTR_FLAG_LEVEL1;

    i2s_pin_config_t pin_config{};
    pin_config.bck_io_num = kMicBck;
    pin_config.ws_io_num = kMicWs;
    pin_config.data_in_num = kMicData;
    pin_config.data_out_num = I2S_PIN_NO_CHANGE;

    ESP_RETURN_ON_ERROR(i2s_driver_install(I2S_NUM_0, &i2s_config, 0, nullptr),
                        kTag, "i2s install");
    ESP_RETURN_ON_ERROR(i2s_set_pin(I2S_NUM_0, &pin_config), kTag, "i2s pin");
    return ESP_OK;
}

esp_err_t SensorHub::init_camera() {
    camera_config_t config{};
    config.ledc_channel = LEDC_CHANNEL_0;
    config.ledc_timer = LEDC_TIMER_0;
    config.pin_d0 = GPIO_NUM_11;
    config.pin_d1 = GPIO_NUM_12;
    config.pin_d2 = GPIO_NUM_13;
    config.pin_d3 = GPIO_NUM_14;
    config.pin_d4 = GPIO_NUM_15;
    config.pin_d5 = GPIO_NUM_16;
    config.pin_d6 = GPIO_NUM_17;
    config.pin_d7 = GPIO_NUM_18;
    config.pin_xclk = GPIO_NUM_10;
    config.pin_pclk = GPIO_NUM_21;
    config.pin_vsync = GPIO_NUM_47;
    config.pin_href = GPIO_NUM_40;
    config.pin_sscb_sda = kPpgSda;
    config.pin_sscb_scl = kPpgScl;
    config.pin_pwdn = GPIO_NUM_41;
    config.pin_reset = GPIO_NUM_NC;
    config.xclk_freq_hz = 16000000;
    config.pixel_format = PIXFORMAT_GRAYSCALE;
    config.frame_size = FRAMESIZE_QQVGA;
    config.jpeg_quality = 12;
    config.fb_count = 1;
    ESP_RETURN_ON_ERROR(esp_camera_init(&config), kTag, "camera");
    return ESP_OK;
}

esp_err_t SensorHub::init_imu() {
    // The BMI270 shares the same I2C bus.
    // A full driver would configure range/ODR; omitted for brevity.
    return ESP_OK;
}

esp_err_t SensorHub::read_ppg(float &hr, float &hrv, bool &valid) {
    // Placeholder: actual implementation would read FIFO from MAX30102
    // and run peak detection on IR samples.
    static float fake = 70.0f;
    fake += 0.1f;
    hr = fake;
    hrv = 40.0f + std::sin(fake) * 5.0f;
    valid = true;
    return ESP_OK;
}

esp_err_t SensorHub::read_voice(float &stress, bool &valid) {
    size_t bytes_read = 0;
    constexpr int16_t kSilence = 10;
    int32_t buffer[256];
    ESP_RETURN_ON_ERROR(i2s_read(I2S_NUM_0, buffer, sizeof(buffer),
                                 &bytes_read, pdMS_TO_TICKS(20)),
                        kTag, "i2s read");
    // Very simple RMS-based stress proxy; replace with MFCC later in pipeline.
    double accum = 0.0;
    size_t samples = bytes_read / sizeof(int32_t);
    for (size_t i = 0; i < samples; ++i) {
        accum += std::abs(buffer[i]);
    }
    stress = accum / std::max<size_t>(1, samples) / 1000.0f;
    valid = stress > kSilence;
    return ESP_OK;
}

esp_err_t SensorHub::read_face(float &blink_rate, float &fatigue, bool &valid) {
    camera_fb_t *fb = esp_camera_fb_get();
    if (!fb) {
        valid = false;
        return ESP_FAIL;
    }
    // Placeholder: run lightweight blink detector with eye aspect ratio.
    blink_rate = 15.0f;     // blinks per minute
    fatigue = 0.4f;         // normalized 0-1
    valid = true;
    esp_camera_fb_return(fb);
    return ESP_OK;
}

esp_err_t SensorHub::read_imu(float &motion_score) {
    motion_score = 0.1f; // static placeholder
    return ESP_OK;
}

