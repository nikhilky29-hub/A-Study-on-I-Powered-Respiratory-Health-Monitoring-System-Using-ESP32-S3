#include <cstring>

#include "ai_processor.hpp"
#include "alerts.hpp"
#include "cloud_client.hpp"
#include "esp_event.h"
#include "esp_log.h"
#include "esp_netif.h"
#include "esp_timer.h"
#include "esp_wifi.h"
#include "feature_pipeline.hpp"
#include "freertos/FreeRTOS.h"
#include "freertos/queue.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "sensors.hpp"

#ifndef CONFIG_WORKER_MONITOR_WIFI_SSID
#define CONFIG_WORKER_MONITOR_WIFI_SSID "ssid"
#endif

#ifndef CONFIG_WORKER_MONITOR_WIFI_PASSWORD
#define CONFIG_WORKER_MONITOR_WIFI_PASSWORD "password"
#endif

namespace {
constexpr char kTag[] = "WorkerMonitor";
constexpr gpio_num_t kConsentButton = GPIO_NUM_1;

SensorHub sensor_hub;
FeaturePipeline feature_pipeline;
AiProcessor ai_processor;
AlertManager alert_manager;
CloudClient cloud_client;

QueueHandle_t sensor_queue;

bool user_consent_granted() {
    return gpio_get_level(kConsentButton) == 1;
}

void init_consent_button() {
    gpio_config_t cfg{};
    cfg.mode = GPIO_MODE_INPUT;
    cfg.pull_up_en = GPIO_PULLUP_ENABLE;
    cfg.pin_bit_mask = (1ULL << kConsentButton);
    gpio_config(&cfg);
}

void wifi_init_sta() {
    ESP_ERROR_CHECK(esp_netif_init());
    ESP_ERROR_CHECK(esp_event_loop_create_default());
    esp_netif_create_default_wifi_sta();

    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ESP_ERROR_CHECK(esp_wifi_init(&cfg));

    wifi_config_t wifi_config{};
    strcpy(reinterpret_cast<char *>(wifi_config.sta.ssid),
           CONFIG_WORKER_MONITOR_WIFI_SSID);
    strcpy(reinterpret_cast<char *>(wifi_config.sta.password),
           CONFIG_WORKER_MONITOR_WIFI_PASSWORD);
    wifi_config.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;

    ESP_ERROR_CHECK(esp_wifi_set_mode(WIFI_MODE_STA));
    ESP_ERROR_CHECK(esp_wifi_set_config(WIFI_IF_STA, &wifi_config));
    ESP_ERROR_CHECK(esp_wifi_start());
    ESP_LOGI(kTag, "wifi_init_sta finished.");
}

void sensor_task(void *) {
    SensorReadings readings;
    while (true) {
        if (sensor_hub.sample(readings) == ESP_OK) {
            xQueueOverwrite(sensor_queue, &readings);
        }
        vTaskDelay(pdMS_TO_TICKS(200));
    }
}

void inference_task(void *) {
    FeatureVector features;
    SensorReadings readings;
    InferenceResult result{};
    while (true) {
        if (xQueueReceive(sensor_queue, &readings, portMAX_DELAY) == pdTRUE) {
            feature_pipeline.build(readings, features);
            if (ai_processor.infer(features, result) == ESP_OK) {
                alert_manager.update(readings, result);
                if (user_consent_granted()) {
                    cloud_client.publish(readings, result);
                }
            }
        }
    }
}
}  // namespace

extern "C" void app_main(void) {
    ESP_ERROR_CHECK(nvs_flash_init());
    wifi_init_sta();
    init_consent_button();
    ESP_ERROR_CHECK(sensor_hub.init());
    ESP_ERROR_CHECK(ai_processor.init());
    ESP_ERROR_CHECK(alert_manager.init());
    ESP_ERROR_CHECK(cloud_client.init());

    sensor_queue = xQueueCreate(1, sizeof(SensorReadings));
    configASSERT(sensor_queue);

    xTaskCreate(sensor_task, "sensor_task", 4096, nullptr, 5, nullptr);
    xTaskCreate(inference_task, "inference_task", 4096, nullptr, 5, nullptr);
}



