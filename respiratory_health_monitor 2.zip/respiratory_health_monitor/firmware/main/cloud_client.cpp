#include "cloud_client.hpp"

#include <cstdio>
#include <cstring>

#include "esp_event.h"
#include "esp_http_client.h"
#include "esp_log.h"
#include "esp_timer.h"
#include "mqtt_client.h"
#include "nvs_flash.h"

namespace {
constexpr char kTag[] = "CloudClient";
constexpr char kBrokerUri[] = "mqtts://example.com:8883";
constexpr char kThingSpeakApiUrl[] = "https://api.thingspeak.com/update";
}  // namespace

static esp_err_t mqtt_event_handler_cb(esp_mqtt_event_handle_t event) {
    switch (event->event_id) {
        case MQTT_EVENT_CONNECTED:
            ESP_LOGI(kTag, "MQTT connected");
            break;
        case MQTT_EVENT_DISCONNECTED:
            ESP_LOGW(kTag, "MQTT disconnected");
            break;
        default:
            break;
    }
    return ESP_OK;
}

static void mqtt_event_handler(void *handler_args, esp_event_base_t base,
                               int32_t event_id, void *event_data) {
    (void)handler_args;
    (void)base;
    (void)event_id;
    mqtt_event_handler_cb(static_cast<esp_mqtt_event_handle_t>(event_data));
}

esp_err_t CloudClient::init() {
#ifdef CONFIG_WORKER_MONITOR_USE_THINGSPEAK
    // ThingSpeak uses HTTP REST API, no persistent connection needed
    ESP_LOGI(kTag, "ThingSpeak client initialized (HTTP REST)");
    return ESP_OK;
#else
    ESP_RETURN_ON_ERROR(nvs_flash_init(), kTag, "nvs");
    esp_mqtt_client_config_t cfg{};
    cfg.broker.address.uri = kBrokerUri;
    cfg.credentials.username = "device";
    cfg.credentials.client_id = "esp32-s3-worker-monitor";
    cfg.buffer_size = 2048;
    client_ = esp_mqtt_client_init(&cfg);
    if (!client_) {
        return ESP_FAIL;
    }
    ESP_RETURN_ON_ERROR(esp_mqtt_client_register_event(
                            client_, static_cast<esp_mqtt_event_id_t>(ESP_EVENT_ANY_ID),
                            mqtt_event_handler, nullptr),
                        kTag, "event register");
    ESP_RETURN_ON_ERROR(esp_mqtt_client_start(client_), kTag, "client start");
    return ESP_OK;
#endif
}

static esp_err_t http_event_handler(esp_http_client_event_t *evt) {
    if (evt->event_id == HTTP_EVENT_ON_FINISH) {
        ESP_LOGD(kTag, "HTTP request finished");
    }
    return ESP_OK;
}

esp_err_t CloudClient::publish(const SensorReadings &readings,
                               const InferenceResult &result) {
#ifdef CONFIG_GUARDIAN_USE_THINGSPEAK
    const int64_t now = esp_timer_get_time() / 1000;
    if (now - last_packet_ms_ < 15000) {  // ThingSpeak free tier: 15s between updates
        return ESP_OK;
    }
    last_packet_ms_ = static_cast<int>(now);

    const char *api_key = CONFIG_WORKER_MONITOR_THINGSPEAK_API_KEY;
    if (!api_key || strlen(api_key) == 0) {
        ESP_LOGW(kTag, "ThingSpeak API key not configured");
        return ESP_ERR_INVALID_ARG;
    }

    // Field mapping: 1=HR, 2=HRV, 3=Voice Stress, 4=Blink Rate, 5=Fatigue, 6=State
    char url[512];
    snprintf(url, sizeof(url),
             "%s?api_key=%s&field1=%.2f&field2=%.2f&field3=%.2f&field4=%.2f&field5=%.2f&field6=%d",
             kThingSpeakApiUrl, api_key, readings.heart_rate_bpm,
             readings.heart_rate_variability, readings.voice_stress_score,
             readings.blink_rate, readings.facial_fatigue_score, result.winning_index);

    esp_http_client_config_t config{};
    config.url = url;
    config.event_handler = http_event_handler;
    config.timeout_ms = 5000;

    esp_http_client_handle_t http_client = esp_http_client_init(&config);
    if (!http_client) {
        ESP_LOGE(kTag, "HTTP client init failed");
        return ESP_FAIL;
    }

    esp_err_t err = esp_http_client_perform(http_client);
    if (err == ESP_OK) {
        int status_code = esp_http_client_get_status_code(http_client);
        if (status_code == 200) {
            ESP_LOGI(kTag, "ThingSpeak update successful");
        } else {
            ESP_LOGW(kTag, "ThingSpeak update failed, status=%d", status_code);
            err = ESP_FAIL;
        }
    } else {
        ESP_LOGE(kTag, "HTTP request failed: %s", esp_err_to_name(err));
    }

    esp_http_client_cleanup(http_client);
    return err;
#else
    if (!client_) {
        return ESP_ERR_INVALID_STATE;
    }
    const int64_t now = esp_timer_get_time() / 1000;
    if (now - last_packet_ms_ < 5000) {
        return ESP_OK;
    }
    last_packet_ms_ = static_cast<int>(now);

    char payload[256];
    snprintf(payload, sizeof(payload),
             R"({"hr":%.2f,"hrv":%.2f,"voice":%.2f,"blink":%.2f,"fatigue":%.2f,"state":%d})",
             readings.heart_rate_bpm,
             readings.heart_rate_variability,
             readings.voice_stress_score,
             readings.blink_rate,
             readings.facial_fatigue_score,
             result.winning_index);

    const int msg_id = esp_mqtt_client_publish(client_, "guardian/state",
                                               payload, 0, 1, false);
    if (msg_id < 0) {
        ESP_LOGW(kTag, "Publish failed");
        return ESP_FAIL;
    }
    return ESP_OK;
#endif
}

void CloudClient::loop() {
    // The ESP-IDF MQTT client runs in the background. Nothing needed here yet.
}


