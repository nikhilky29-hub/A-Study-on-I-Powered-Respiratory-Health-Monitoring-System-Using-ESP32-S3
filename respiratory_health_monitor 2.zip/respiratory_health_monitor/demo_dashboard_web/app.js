const hrEl = document.getElementById("hr-value");
const hrvEl = document.getElementById("hrv-value");
const voiceEl = document.getElementById("voice-value");
const fatigueEl = document.getElementById("fatigue-value");
const blinkEl = document.getElementById("blink-value");
const stateEl = document.getElementById("state-value");
const logEl = document.getElementById("event-log");
const alertBadgeEl = document.getElementById("header-alert-badge");

const barMap = {
  normal: document.getElementById("bar-normal"),
  fatigued: document.getElementById("bar-fatigued"),
  stressed: document.getElementById("bar-stressed"),
  critical: document.getElementById("bar-critical"),
};

const pctMap = {
  normal: document.getElementById("prob-normal"),
  fatigued: document.getElementById("prob-fatigued"),
  stressed: document.getElementById("prob-stressed"),
  critical: document.getElementById("prob-critical"),
};

// Chart instances
let charts = {
  hr: null, hrv: null, voice: null, blink: null, fatigue: null, state: null
};

// Chart data storage
const MAX_DATA_POINTS = 50;
let chartData = {
  hr: { labels: [], values: [] },
  hrv: { labels: [], values: [] },
  voice: { labels: [], values: [] },
  blink: { labels: [], values: [] },
  fatigue: { labels: [], values: [] },
  state: { labels: [], values: [] }
};

let time = 0;
let fatigue = 0.3;
let stress = 0.2;
let motion = 0.1;

function clamp(val, min, max) {
  return Math.min(max, Math.max(min, val));
}

function log(message) {
  if (!logEl) return;
  const item = document.createElement("li");
  const timestamp = new Date().toLocaleTimeString();
  item.textContent = `[${timestamp}] ${message}`;
  logEl.prepend(item);
  while (logEl.children.length > 8) {
    logEl.removeChild(logEl.lastChild);
  }
}

function simulateSensors() {
  time += 0.2;
  const circadian = Math.sin(time * 0.05) * 5;
  const heartRate = 72 + circadian + Math.sin(time * 0.8) * 3 + Math.random() * 2;
  const hrv = 45 + Math.sin(time * 0.7) * 8 - stress * 10;

  // stress spikes
  if (Math.random() > 0.92) stress = clamp(stress + 0.3, 0, 1);
  else stress *= 0.98;

  // fatigue drifts
  if (Math.random() > 0.95) fatigue = clamp(fatigue + 0.2, 0, 1);
  else fatigue *= 0.995;

  motion = clamp(stress * 0.5 + Math.random() * 0.2, 0, 1);

  const voice = clamp(0.15 + stress + Math.random() * 0.05, 0, 1);
  const blinkRate = 18 - fatigue * 8 + Math.random() * 2;
  const fatigueScore = clamp(fatigue + Math.random() * 0.02, 0, 1);

  return {
    heartRate,
    hrv,
    voice,
    blinkRate,
    fatigueScore,
    motion,
  };
}

// TensorFlow.js model
let mlModel = null;
let modelLoaded = false;

// Load ML model - try backend first, then TensorFlow.js, then heuristic
async function loadMLModel() {
  if (modelLoaded) return;
  
  // First, check if ML backend is available (preferred - uses real .tflite model)
  try {
    const response = await fetch('http://localhost:5000/health', { method: 'GET', mode: 'cors' });
    if (response.ok) {
      const healthData = await response.json();
      if (healthData.models_loaded.includes('respiratory_health_monitor')) {
        modelLoaded = true;
        log("✓ ML Backend server available - using real TinyML models");
        return true;
      }
    }
  } catch (error) {
    // Backend not available, continue to TensorFlow.js
  }
  
  // Fallback to TensorFlow.js (only if backend is not available)
  // Note: TensorFlow.js models may not exist - this is expected if using backend
  try {
    const modelPath = '../ml/training/artifacts/tfjs_model/model.json';
    mlModel = await tf.loadLayersModel(modelPath);
    modelLoaded = true;
    log("✓ TensorFlow.js model loaded successfully - using real ML inference");
    return true;
  } catch (error) {
    // TensorFlow.js model not available - this is OK if using backend
    // Only log as warning if backend was also unavailable
    if (error.message && error.message.includes('404')) {
      // Suppress 404 errors - TensorFlow.js models are optional when using backend
      console.log("TensorFlow.js model not found (this is OK if ML backend is running)");
    } else {
      console.warn("Could not load TensorFlow.js model, using heuristic fallback:", error);
    }
    return false;
  }
}

async function runTinyModel(features) {
  const hr = clamp((features.heartRate - 40) / 120, 0, 1);
  const hrv = clamp((features.hrv - 10) / 110, 0, 1);
  const voice = features.voice;
  const blink = clamp((features.blinkRate - 5) / 35, 0, 1);
  const fatigue = features.fatigueScore;
  const motion = features.motion;

  // Build 16-feature vector
  const featureVector = [
    hr, hrv, voice, blink, fatigue, motion,
    1.0, 1.0, 1.0, // validity
    fatigue, fatigue, fatigue, fatigue, fatigue, fatigue, fatigue
  ].slice(0, 16);

  // Try ML backend first (preferred - uses real .tflite model)
  if (modelLoaded) {
    try {
      const response = await fetch('http://localhost:5000/infer', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        mode: 'cors',
        body: JSON.stringify({
          project: 'respiratory_health_monitor',
          features: featureVector
        })
      });
      
      if (response.ok) {
        const data = await response.json();
        return data.probabilities;
      }
    } catch (error) {
      // Backend unavailable, try TensorFlow.js
    }
  }

  // Fallback to TensorFlow.js model
  if (modelLoaded && mlModel) {
    try {
      const input = tf.tensor2d([featureVector], [1, 16]);
      const prediction = mlModel.predict(input);
      const probs = await prediction.data();
      input.dispose();
      prediction.dispose();
      return Array.from(probs);
    } catch (error) {
      console.error("Model inference error:", error);
      // Fall through to heuristic
    }
  }

  // Heuristic fallback
  const logits = [
    1.2 - fatigue * 0.8 - voice * 0.6 - motion * 0.5,
    fatigue * 1.4 + (1 - blink) * 0.6,
    voice * 1.5 + (1 - hrv) * 0.8,
    motion * 1.2 + hr * 0.8 + (1 - hrv) * 0.6,
  ];
  const exp = logits.map((l) => Math.exp(l));
  const sum = exp.reduce((a, b) => a + b, 0);
  return exp.map((v) => v / sum);
}

function updateBars(probabilities) {
  if (!Array.isArray(probabilities)) {
    console.error("probabilities is not an array:", probabilities);
    return "Normal";
  }
  
  const states = ["normal", "fatigued", "stressed", "critical"];
  let winner = 0;
  
  probabilities.forEach((p, idx) => {
    const bar = barMap[states[idx]];
    if (bar) {
      bar.style.width = `${(p * 100).toFixed(1)}%`;
    }
    const pct = pctMap[states[idx]];
    if (pct) {
      pct.textContent = `${(p * 100).toFixed(0)}%`;
    }
    if (p > probabilities[winner]) winner = idx;
  });

  return ["Normal", "Fatigued", "Stressed", "Critical"][winner];
}

async function updateUI(readings, probs, label) {
  if (hrEl) hrEl.textContent = `${readings.heartRate.toFixed(1)} bpm`;
  if (hrvEl) hrvEl.textContent = `${readings.hrv.toFixed(1)} ms`;
  if (voiceEl) voiceEl.textContent = readings.voice.toFixed(2);
  if (fatigueEl) fatigueEl.textContent = readings.fatigueScore.toFixed(2);
  if (blinkEl) blinkEl.textContent = `${readings.blinkRate.toFixed(1)}`;
  
  const stateNames = ["Normal", "Fatigued", "Stressed", "Critical"];
  const stateIdx = probs.indexOf(Math.max(...probs));
  if (stateEl) stateEl.textContent = stateNames[stateIdx];
  if (alertBadgeEl) alertBadgeEl.textContent = stateNames[stateIdx];
  
  updateCharts(readings, stateIdx);
  log(`State: ${label} | probs ${probs.map((p) => p.toFixed(2)).join(", ")}`);
}

// Initialize charts
function initializeCharts() {
  const chartOptions = {
    responsive: true,
    maintainAspectRatio: false,
    plugins: { legend: { display: false }, tooltip: { mode: 'index', intersect: false } },
    scales: {
      x: { grid: { color: 'rgba(255, 255, 255, 0.1)' }, ticks: { color: 'rgba(255, 255, 255, 0.7)', maxTicksLimit: 10 } },
      y: { grid: { color: 'rgba(255, 255, 255, 0.1)' }, ticks: { color: 'rgba(255, 255, 255, 0.7)' } }
    },
    elements: { point: { radius: 2, hoverRadius: 4 }, line: { tension: 0.4, borderWidth: 2 } }
  };

  try {
    const hrCanvas = document.getElementById('chart-hr');
    if (hrCanvas) {
      charts.hr = new Chart(hrCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#e91e63', backgroundColor: 'rgba(233, 30, 99, 0.1)', fill: true }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 50, max: 120 } } }
      });
    }

    const hrvCanvas = document.getElementById('chart-hrv');
    if (hrvCanvas) {
      charts.hrv = new Chart(hrvCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#2196f3', backgroundColor: 'rgba(33, 150, 243, 0.1)', fill: true }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 20, max: 80 } } }
      });
    }

    const voiceCanvas = document.getElementById('chart-voice');
    if (voiceCanvas) {
      charts.voice = new Chart(voiceCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#ff9800', backgroundColor: 'rgba(255, 152, 0, 0.1)', fill: true }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 1 } } }
      });
    }

    const blinkCanvas = document.getElementById('chart-blink');
    if (blinkCanvas) {
      charts.blink = new Chart(blinkCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#9c27b0', backgroundColor: 'rgba(156, 39, 176, 0.1)', fill: true }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 5, max: 25 } } }
      });
    }

    const fatigueCanvas = document.getElementById('chart-fatigue');
    if (fatigueCanvas) {
      charts.fatigue = new Chart(fatigueCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#ff5722', backgroundColor: 'rgba(255, 87, 34, 0.1)', fill: true }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: 0, max: 1 } } }
      });
    }

    const stateCanvas = document.getElementById('chart-state');
    if (stateCanvas) {
      charts.state = new Chart(stateCanvas, {
        type: 'line', data: { labels: [], datasets: [{ data: [], borderColor: '#f44336', backgroundColor: 'rgba(244, 67, 54, 0.1)', fill: true, stepped: 'after' }] },
        options: { ...chartOptions, scales: { ...chartOptions.scales, y: { ...chartOptions.scales.y, min: -0.5, max: 3.5, ticks: { stepSize: 1, callback: v => ['Normal', 'Fatigued', 'Stressed', 'Critical'][v] || '' } } } }
      });
    }
  } catch (error) {
    console.error("Failed to create chart:", error);
  }
}

function updateCharts(readings, stateIdx) {
  const now = new Date().toLocaleTimeString();
  
  function addData(chartName, value) {
    const data = chartData[chartName];
    if (data) {
      data.labels.push(now);
      data.values.push(value);
      if (data.labels.length > MAX_DATA_POINTS) { data.labels.shift(); data.values.shift(); }
    }
  }

  addData('hr', readings.heartRate);
  addData('hrv', readings.hrv);
  addData('voice', readings.voice);
  addData('blink', readings.blinkRate);
  addData('fatigue', readings.fatigueScore);
  addData('state', stateIdx);

  Object.keys(charts).forEach(key => {
    if (charts[key] && chartData[key]) {
      charts[key].data.labels = chartData[key].labels;
      charts[key].data.datasets[0].data = chartData[key].values;
      charts[key].update('none');
    }
  });
}

if (document.readyState === 'loading') {
  document.addEventListener('DOMContentLoaded', initializeCharts);
} else {
  initializeCharts();
}

(async () => {
  await loadMLModel();
  log("System initialized. Monitoring respiratory health...");
  
  setInterval(async () => {
    const readings = simulateSensors();
    const probs = await runTinyModel(readings);
    if (Array.isArray(probs)) {
      const state = updateBars(probs);
      await updateUI(readings, probs, state);
    }
  }, 1000);
})();
